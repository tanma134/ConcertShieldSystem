import { Routes, Route } from "react-router-dom";
import RegisterPage from "../pages/RegisterPage";
import VerifyEmailPage from "../pages/VerifyEmailPage";
import LoginPage from "../pages/LoginPage";
import ForgotPasswordPage from "../pages/ForgotPasswordPage";
import VerifyResetOtpPage from "../pages/VerifyResetOtpPage";
import ResetPasswordPage from "../pages/ResetPasswordPage";
import HomePage from "../pages/HomePage";
import EventDetailPage from "../pages/EventDetailPage";
import MyConcertsPage from "../pages/organizer/MyConcertsPage";
import OrganizerDashboardPage from "../pages/organizer/OrganizerDashboardPage";
import CreateEventWizard from "../pages/organizer/CreateEventWizard";
import AdminEventsPage from "../pages/admin/AdminEventsPage";
import AdminAllEventsPage from "../pages/admin/AdminAllEventsPage";
import AdminEventDetailPage from "../pages/admin/AdminEventDetailPage";
import ProtectedRoute from "./ProtectedRoute";
import AdminLoginPage from "../pages/AdminLoginPage";
import AdminDashboardPage from "../pages/admin/AdminDashboardPage";
import AdminRoute from "./AdminRoute";
import OrganizerRequestsAdminPage from "../pages/admin/OrganizerRequestsAdminPage";
import ReviewManagementPage from "../pages/admin/ReviewManagementPage";
import UserManagementPage from "../pages/admin/UserManagementPage";
import RoleManagementPage from "../pages/admin/RoleManagementPage";
import RequestOrganizerPage from "../pages/RequestOrganizerPage";
import KycPage from "../pages/KycPage";
import MyProfilePage from "../pages/MyProfilePage";
import EditProfilePage from "../pages/EditProfilePage";
import WishlistManagementPage from "../pages/admin/WishlistManagementPage";
import EventConfigurationPage from "../pages/organizer/EventConfigurationPage";
import AdminSeatingTemplatesPage from "../pages/admin/AdminSeatingTemplatesPage";
import VoucherManagementPage from "../pages/admin/VoucherManagementPage";
import NotificationCenterPage from "../pages/NotificationCenterPage";
import SelectTicketPage from "../pages/customer/SelectTicketPage";
import QuestionFormPage from "../pages/customer/QuestionFormPage";
import PaymentInfoPage from "../pages/customer/PaymentInfoPage";
import PaymentResult from "../pages/customer/PaymentResult";
import KycConsentAdminPage from "../pages/admin/KycConsentAdminPage";
import KycDeletionAdminPage from "../pages/admin/KycDeletionAdminPage";
import KycImagesAdminPage from "../pages/admin/KycImagesAdminPage";
import KycSettingsAdminPage from "../pages/admin/KycSettingsAdminPage";
import KycAccessLogAdminPage from "../pages/admin/KycAccessLogAdminPage";
import AuditLogAdminPage from "../pages/admin/AuditLogAdminPage";
import ChangePasswordPage from "../pages/ChangePasswordPage";
import FraudAlertDashboardPage from "../pages/admin/FraudAlertDashboardPage";
import FraudAlertDetailPage from "../pages/admin/FraudAlertDetailPage";
import RiskDecisionDetailPage from "../pages/admin/RiskDecisionDetailPage";
import AppealAdminListPage from "../pages/admin/AppealAdminListPage";
import RiskBlocksPage from "../pages/admin/RiskBlocksPage";
import FraudCaseListPage from "../pages/admin/FraudCaseListPage";
import RiskPolicyPage from "../pages/admin/RiskPolicyPage";
import AppealReviewPage from "../pages/admin/AppealReviewPage";
import SubmitAppealPage from "../pages/SubmitAppealPage";
import MyTicketsPage from "../pages/customer/MyTicketsPage";
import TicketDetailsPage from "../pages/customer/TicketDetailsPage";
import MyOrdersPage from "../pages/customer/MyOrdersPage";
import OrderDetailsPage from "../pages/customer/OrderDetailsPage";
import RevenueDashboardPage from "../pages/organizer/RevenueDashboardPage";
import CheckinManagementPage from "../pages/organizer/CheckinManagementPage";
import TicketReturnReviewPage from "../pages/admin/TicketReturnReviewPage";
import RefundReconciliationPage from "../pages/admin/RefundReconciliationPage";
import EventGovernancePage from "../pages/organizer/EventGovernancePage";
import ChangeRequestsPage from "../pages/admin/ChangeRequestsPage";
import VirtualQueuePage from "../pages/VirtualQueuePage";
import TicketPlaceholderPage from "../pages/TicketPlaceholderPage";
import QueueManagementPage from "../pages/admin/QueueManagementPage";
import QueueAbuseAlertsPage from "../pages/admin/QueueAbuseAlertsPage";
import QueueAbuseAlertDetailPage from "../pages/admin/QueueAbuseAlertDetailPage";

// --- from feature/scandynamicQRtitket ---
import TicketGovernancePage from "../pages/admin/TicketGovernancePage";
import SystemPoliciesPage from "../pages/admin/SystemPoliciesPage";
import OrganizerVerificationsPage from "../pages/admin/OrganizerVerificationsPage";
import SubmitOrganizerVerificationPage from "../pages/organizer/SubmitOrganizerVerificationPage";
import RealtimeCheckinMonitorPage from "../pages/organizer/RealtimeCheckinMonitorPage";
import ViewGateAssignmentPage from "../pages/staff/ViewGateAssignmentPage";
import StaffCheckinTerminalPage from "../pages/staff/StaffCheckinTerminalPage";

// --- from develop ---
import IncidentListPage from "../pages/staff/IncidentListPage";
import IncidentReportPage from "../pages/staff/IncidentReportPage";
import IncidentDetailPage from "../pages/staff/IncidentDetailPage";
import CheckinScanTerminalPage from "../pages/staff/CheckinScanTerminalPage";
import SupportCaseListPage from "../pages/support/SupportCaseListPage";
import SupportCaseCreatePage from "../pages/support/SupportCaseCreatePage";
import SupportCaseDetailPage from "../pages/support/SupportCaseDetailPage";
import PaymentReconciliationExceptionsPage from "../pages/admin/PaymentReconciliationExceptionsPage";
import TicketStatusHistoryPage from "../pages/admin/TicketStatusHistoryPage";
import AdminTicketsPage from "../pages/admin/AdminTicketsPage";
import AdminTicketDetailPage from "../pages/admin/AdminTicketDetailPage";
import FailedTransactionQueuePage from "../pages/admin/FailedTransactionQueuePage";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/organizer/events/:id/compliance" element={<ProtectedRoute organizerOnly><EventGovernancePage /></ProtectedRoute>} />
      <Route path="/organizer/events/:id/changes" element={<ProtectedRoute organizerOnly><EventGovernancePage /></ProtectedRoute>} />
      <Route path="/admin/change-requests" element={<ProtectedRoute adminOnly><ChangeRequestsPage /></ProtectedRoute>} />
      <Route path="/admin/events/:id/governance" element={<ProtectedRoute adminOnly><EventGovernancePage admin /></ProtectedRoute>} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/verify-email" element={<VerifyEmailPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/verify-reset-otp" element={<VerifyResetOtpPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />

      {/* Home page and event detail are public, just like the real Ticketbox -
          the matching EventAPI endpoints are all [AllowAnonymous]. */}
      <Route path="/" element={<HomePage />} />
      <Route path="/events/:slug" element={<EventDetailPage />} />
      <Route path="/events/:eventId/queue" element={<ProtectedRoute><VirtualQueuePage /></ProtectedRoute>} />
      <Route path="/events/:eventId/tickets" element={<ProtectedRoute><TicketPlaceholderPage /></ProtectedRoute>} />
      <Route path="/profile" element={<ProtectedRoute><MyProfilePage /></ProtectedRoute>} />
      <Route path="/profile/edit" element={<ProtectedRoute><EditProfilePage /></ProtectedRoute>} />
      <Route path="/profile/change-password" element={<ProtectedRoute><ChangePasswordPage /></ProtectedRoute>} />

      <Route path="/events/:eventId/select-tickets" element={<SelectTicketPage />} />
      <Route
        path="/checkout/question-form/:holdId"
        element={
          <ProtectedRoute>
            <QuestionFormPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/checkout/payment-info/:holdId"
        element={
          <ProtectedRoute>
            <PaymentInfoPage />
          </ProtectedRoute>
        }
      />
      <Route path="/payment/result" element={<PaymentResult />} />

      <Route
        path="/my-tickets"
        element={
          <ProtectedRoute>
            <MyTicketsPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/my-tickets/:ticketId"
        element={
          <ProtectedRoute>
            <TicketDetailsPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/my-orders"
        element={
          <ProtectedRoute>
            <MyOrdersPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/my-orders/:orderId"
        element={
          <ProtectedRoute>
            <OrderDetailsPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/payment-reconciliation"
        element={
          <ProtectedRoute adminOnly>
            <PaymentReconciliationExceptionsPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/ticket-status-history"
        element={
          <ProtectedRoute adminOnly>
            <TicketStatusHistoryPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/failed-transaction-queue"
        element={
          <ProtectedRoute adminOnly>
            <FailedTransactionQueuePage />
          </ProtectedRoute>
        }
      />

      {/* UC_9 return review (Staff/Admin) */}
      <Route path="/staff/returns" element={<ProtectedRoute><TicketReturnReviewPage /></ProtectedRoute>} />
      <Route path="/admin/returns" element={<ProtectedRoute adminOnly><TicketReturnReviewPage /></ProtectedRoute>} />
      {/* 3.16.22 Refund Reconciliation Report */}
      <Route path="/admin/refund-reconciliation" element={<ProtectedRoute adminOnly><RefundReconciliationPage /></ProtectedRoute>} />

      {/* Gate Check-in & Re-entry Terminal.
          NOTE: /staff/checkin/:eventId (StaffCheckinTerminalPage) is declared in the
          "Staff Check-in & Gate Assignment" block below. */}
      <Route path="/staff/checkin" element={<ProtectedRoute><CheckinScanTerminalPage /></ProtectedRoute>} />
      <Route path="/admin/checkin" element={<AdminRoute><CheckinScanTerminalPage /></AdminRoute>} />

      {/* UC_16 On-site Incident Management (UC_16.1 - UC_16.5) */}
      <Route path="/staff/incidents" element={<ProtectedRoute><IncidentListPage /></ProtectedRoute>} />
      <Route path="/staff/incidents/new" element={<ProtectedRoute><IncidentReportPage /></ProtectedRoute>} />
      <Route path="/staff/incidents/:id" element={<ProtectedRoute><IncidentDetailPage /></ProtectedRoute>} />

      <Route path="/admin/incidents" element={<AdminRoute><IncidentListPage /></AdminRoute>} />
      <Route path="/admin/incidents/new" element={<AdminRoute><IncidentReportPage /></AdminRoute>} />
      <Route path="/admin/incidents/:id" element={<AdminRoute><IncidentDetailPage /></AdminRoute>} />

      {/* Support Case Management & Dispute Resolution */}
      <Route path="/staff/support-cases" element={<ProtectedRoute><SupportCaseListPage /></ProtectedRoute>} />
      <Route path="/staff/support-cases/new" element={<ProtectedRoute><SupportCaseCreatePage /></ProtectedRoute>} />
      <Route path="/staff/support-cases/:id" element={<ProtectedRoute><SupportCaseDetailPage /></ProtectedRoute>} />

      <Route path="/admin/support-cases" element={<AdminRoute><SupportCaseListPage /></AdminRoute>} />
      <Route path="/admin/support-cases/new" element={<AdminRoute><SupportCaseCreatePage /></AdminRoute>} />
      <Route path="/admin/support-cases/:id" element={<AdminRoute><SupportCaseDetailPage /></AdminRoute>} />

      {/* UC_13 revenue dashboard and UC_14 check-in report / staff (the organizer of the concert). */}
      <Route path="/organizer/events/:id/revenue" element={<ProtectedRoute organizerOnly><RevenueDashboardPage /></ProtectedRoute>} />
      <Route path="/organizer/events/:id/checkin" element={<ProtectedRoute organizerOnly><CheckinManagementPage /></ProtectedRoute>} />
      <Route path="/organizer/events/:id/staff" element={<ProtectedRoute organizerOnly><CheckinManagementPage /></ProtectedRoute>} />

      {/* Any logged-in Customer may create and configure a Draft concert. */}
      <Route
        path="/organizer/dashboard"
        element={
          <ProtectedRoute>
            <OrganizerDashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/organizer/events"
        element={
          <ProtectedRoute>
            <MyConcertsPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/organizer/events/new"
        element={
          <ProtectedRoute organizerOnly>
            <CreateEventWizard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/organizer/events/:id/edit"
        element={
          <ProtectedRoute organizerOnly>
            <CreateEventWizard />
          </ProtectedRoute>
        }
      />
      {[
        ["seating", "seating"], ["pricing", "pricing"], ["refunds", "refunds"],
      ].map(([path, section]) => <Route key={path} path={`/organizer/events/:id/${path}`} element={<ProtectedRoute organizerOnly><EventConfigurationPage section={section} /></ProtectedRoute>} />)}

      {/* Admin moderation queue - requires the Admin role. */}
      <Route
        path="/admin/events"
        element={
          <ProtectedRoute adminOnly>
            <AdminEventsPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/events/all"
        element={
          <ProtectedRoute adminOnly>
            <AdminAllEventsPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/events/:id"
        element={
          <ProtectedRoute adminOnly>
            <AdminEventDetailPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/tickets"
        element={
          <ProtectedRoute adminOnly>
            <AdminTicketsPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/tickets/:ticketId"
        element={
          <ProtectedRoute adminOnly>
            <AdminTicketDetailPage />
          </ProtectedRoute>
        }
      />

      {/* User gui yeu cau tro thanh Organizer */}
      <Route
        path="/organizer/request"
        element={
          <ProtectedRoute>
            <RequestOrganizerPage />
          </ProtectedRoute>
        }
      />

      {/* Xac thuc danh tinh (eKYC) bang camera */}
      <Route
        path="/kyc"
        element={
          <ProtectedRoute>
            <KycPage />
          </ProtectedRoute>
        }
      />

      {/* Khu vuc Admin */}
      <Route path="/admin/login" element={<AdminLoginPage />} />
      <Route
        path="/admin"
        element={
          <AdminRoute>
            <AdminDashboardPage />
          </AdminRoute>
        }
      />
      <Route path="/admin/queue" element={<AdminRoute><QueueManagementPage /></AdminRoute>} />
      <Route path="/admin/queue/abuse-alerts" element={<AdminRoute><QueueAbuseAlertsPage /></AdminRoute>} />
      <Route path="/admin/queue/abuse-alerts/:alertId" element={<AdminRoute><QueueAbuseAlertDetailPage /></AdminRoute>} />
      <Route
        path="/admin/users"
        element={
          <AdminRoute>
            <UserManagementPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/roles"
        element={
          <AdminRoute>
            <RoleManagementPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/organizer-requests"
        element={
          <AdminRoute>
            <OrganizerRequestsAdminPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/reviews"
        element={
          <AdminRoute>
            <ReviewManagementPage />
          </AdminRoute>
        }
      />
      {/* Notifications - Available for Customer & Organizer */}
      <Route path="/notifications" element={<ProtectedRoute><NotificationCenterPage /></ProtectedRoute>} />

      {/* Voucher Management - Organizer */}
      <Route path="/organizer/vouchers" element={<ProtectedRoute organizerOnly><VoucherManagementPage /></ProtectedRoute>} />

      <Route path="/admin/wishlists" element={<AdminRoute><WishlistManagementPage /></AdminRoute>} />
      <Route path="/admin/kyc/consent" element={<AdminRoute><KycConsentAdminPage /></AdminRoute>} />
      <Route path="/admin/kyc/deletion-requests" element={<AdminRoute><KycDeletionAdminPage /></AdminRoute>} />
      <Route path="/admin/kyc-images" element={<AdminRoute><KycImagesAdminPage /></AdminRoute>} />
      <Route path="/admin/kyc/settings" element={<AdminRoute><KycSettingsAdminPage /></AdminRoute>} />
      <Route path="/admin/kyc/access-logs" element={<AdminRoute><KycAccessLogAdminPage /></AdminRoute>} />
      <Route path="/admin/audit-logs" element={<AdminRoute><AuditLogAdminPage /></AdminRoute>} />
      <Route path="/admin/fraud-alerts" element={<AdminRoute><FraudAlertDashboardPage /></AdminRoute>} />
      <Route path="/admin/fraud-alerts/:id" element={<AdminRoute><FraudAlertDetailPage /></AdminRoute>} />
      <Route path="/admin/risk/decisions/:id" element={<AdminRoute><RiskDecisionDetailPage /></AdminRoute>} />
      <Route path="/admin/fraud-cases" element={<AdminRoute><FraudCaseListPage /></AdminRoute>} />
      <Route path="/admin/risk/policy" element={<AdminRoute><RiskPolicyPage /></AdminRoute>} />
      <Route path="/admin/risk/blocks" element={<AdminRoute><RiskBlocksPage /></AdminRoute>} />
      <Route path="/admin/risk/appeals" element={<AdminRoute><AppealAdminListPage /></AdminRoute>} />
      <Route path="/admin/risk/appeals/:id" element={<AdminRoute><AppealReviewPage /></AdminRoute>} />
      <Route path="/risk/decisions/:id/appeal" element={<ProtectedRoute><SubmitAppealPage /></ProtectedRoute>} />
      <Route path="/admin/seating-templates" element={<AdminRoute><AdminSeatingTemplatesPage /></AdminRoute>} />
      <Route path="/admin/vouchers" element={<AdminRoute><VoucherManagementPage /></AdminRoute>} />

      {/* Staff Check-in & Gate Assignment (UC_15.1, 15.2, 15.3, 15.4, 15.5, 14.5, 14.6, 14.7) */}
      <Route path="/staff/gate-assignment" element={<ProtectedRoute staffOnly><ViewGateAssignmentPage /></ProtectedRoute>} />
      <Route path="/staff/gate-assignment/:eventId" element={<ProtectedRoute staffOnly><ViewGateAssignmentPage /></ProtectedRoute>} />
      <Route path="/staff/checkin/:eventId" element={<ProtectedRoute staffOnly><StaffCheckinTerminalPage /></ProtectedRoute>} />

      {/* Admin Ticket Governance, Policies & Verifications (UC_8.7, 8.8, 8.10, 11.1, 11.2, 11.4, 11.5) */}
      <Route path="/admin/ticket-governance" element={<AdminRoute><TicketGovernancePage /></AdminRoute>} />
      <Route path="/admin/policies" element={<AdminRoute><SystemPoliciesPage /></AdminRoute>} />
      <Route path="/admin/organizer-verifications" element={<AdminRoute><OrganizerVerificationsPage /></AdminRoute>} />

      {/* Organizer Verification & Real-time Check-in Monitor (UC_11.3, 14.1, 14.7) */}
      <Route path="/organizer/verification" element={<ProtectedRoute><SubmitOrganizerVerificationPage /></ProtectedRoute>} />
      <Route path="/organizer/events/:eventId/realtime-checkin" element={<ProtectedRoute organizerOnly><RealtimeCheckinMonitorPage /></ProtectedRoute>} />
      <Route path="/organizer/realtime-checkin" element={<ProtectedRoute organizerOnly><RealtimeCheckinMonitorPage /></ProtectedRoute>} />
    </Routes>
  );
}
