using AuthenticationAPI.Models;

namespace AuthenticationAPI.Repositories
{
    public interface IEkycRepository
    {
        Task<int> CreateAsync(EkycVerification record);

        /// <summary>
        /// L�u record. N?u truy?n userEkycStatus th? c?p nh?t lu�n User.EkycStatus trong c�ng 1 l?n SaveChanges
        /// (kh�ng bao gi? h? c?p user �ang ? tr?ng th�i "Passed").
        /// </summary>
        Task UpdateAsync(EkycVerification record, string? userEkycStatus = null);

        Task<EkycVerification?> GetByIdAsync(int ekycId);

        /// <summary>Record m?i nh?t c?a user c� tr?ng th�i Passed ho?c ManualReview (null n?u ch�a c�).</summary>
        Task<EkycVerification?> GetActiveByUserAsync(int userId);

        /// <summary>CCCD (theo hash) �? ��?c t�i kho?n KH�C x�c th?c/�ang ch? duy?t ch�a.</summary>
        Task<bool> IsCccdUsedByAnotherUserAsync(string cccdHash, int userId);

        /// <summary>N record m?i nh?t c?a user (m?i nh?t tr�?c), d�ng �? �?m s? l?n th?t b?i li�n ti?p .</summary>
        Task<List<EkycVerification>> GetRecentByUserAsync(int userId, int take);
    }
}