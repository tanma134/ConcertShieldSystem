using System.Security.Claims;
using AuthenticationAPI.DTOs;
using AuthenticationAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthenticationAPI.Controllers
{
    [ApiController]
    [Route("api/kyc")]
    [Authorize(Policy = "Customer")] // only a Customer can use eKYC
    public class KycController : ControllerBase
    {
        private const long MaxImageBytes = 6 * 1024 * 1024; // 3 ?nh x 6MB < gi?i h?n request 20MB
        private static readonly string[] AllowedContentTypes = { "image/jpeg", "image/png" };

        private readonly IKycService _kycService;
        private readonly IKycConsentService _consentService;
        private readonly IKycAccessLogService _accessLog;
        private readonly ILogger<KycController> _logger;

        public KycController(IKycService kycService, IKycConsentService consentService,
                             IKycAccessLogService accessLog, ILogger<KycController> logger)
        {
            _kycService = kycService;
            _consentService = consentService;
            _accessLog = accessLog;
            _logger = logger;
        }

        /// <summary>N?i dung th�ng b�o/�?ng ? (phi�n b?n �ang active trong DB) �? frontend hi?n th? tr�?c khi cho g?i ?nh.</summary>
        [HttpGet("consent")]
        public async Task<IActionResult> GetConsent()
        {
            try
            {
                return Ok(await _consentService.GetActiveAsync());
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Ch�a c?u h?nh n?i dung �?ng ? eKYC");
                return StatusCode(503, new { message = "N?i dung �?ng ? ch�a ��?c c?u h?nh, vui l?ng th? l?i sau" });
            }
        }

        [HttpPost("submit")]
        [RequestSizeLimit(20 * 1024 * 1024)]
        public async Task<IActionResult> Submit([FromForm] EkycSubmitRequestDto request)
        {
            if (!TryGetCurrentUserId(out var userId))
                return Unauthorized(new { message = "Token kh�ng h?p l?" });

            // 1) Ph?i c� �?ng ? r? r�ng, ��ng phi�n b?n n?i dung hi?n h�nh
            if (!request.ConsentAccepted)
                return BadRequest(new { message = "B?n c?n �?ng ? v?i n?i dung x? l? d? li?u c� nh�n �? ti?p t?c x�c th?c" });

            string currentVersion;
            try
            {
                currentVersion = await _consentService.GetActiveVersionAsync();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Ch�a c?u h?nh n?i dung �?ng ? eKYC");
                return StatusCode(503, new { message = "N?i dung �?ng ? ch�a ��?c c?u h?nh, vui l?ng th? l?i sau" });
            }

            if (request.ConsentVersion != currentVersion)
                return BadRequest(new { message = "N?i dung �?ng ? �? ��?c c?p nh?t, vui l?ng �?c l?i v� x�c nh?n" });

            // 2) Ki?m tra s� b? file tr�?c khi t?n l�?t g?i VNPT
            var fileError = ValidateImage(request.CccdFrontImage, "m?t tr�?c CCCD")
                         ?? ValidateImage(request.CccdBackImage, "m?t sau CCCD")
                         ?? ValidateImage(request.SelfieImage, "selfie");
            if (fileError is not null)
                return BadRequest(new { message = fileError });

            try
            {
                var result = await _kycService.SubmitAsync(request, userId, HttpContext.Connection.RemoteIpAddress?.ToString());
                return Ok(result);
            }
            catch (EkycLockedException ex)
            {
                // 3 consecutive failures -> locked for 24 hours
                return StatusCode(423, new
                {
                    message = $"B?n �? x�c th?c th?t b?i 3 l?n li�n ti?p. Vui l?ng th? l?i sau {ex.LockedUntilUtc:yyyy-MM-dd HH:mm} (UTC).",
                    lockedUntil = DateTime.SpecifyKind(ex.LockedUntilUtc, DateTimeKind.Utc)
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "L?i khi x? l? submit eKYC cho user {UserId}", userId);
                return StatusCode(500, new { message = "C� l?i x?y ra khi x? l? x�c th?c, vui l?ng th? l?i" });
            }
        }

        [HttpGet("status/{ekycId:int}")]
        public async Task<IActionResult> GetStatus(int ekycId)
        {
            if (!TryGetCurrentUserId(out var userId))
                return Unauthorized(new { message = "Token kh�ng h?p l?" });

            try
            {
                var result = await _kycService.GetStatusAsync(ekycId, userId);
                return Ok(result);
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { message = "Kh�ng t?m th?y b?n ghi eKYC" });
            }
            catch (UnauthorizedAccessException)
            {
                return Forbid();
            }
        }

        /// <summary> the user can see who accessed their eKYC data and for what purpose.</summary>
        [HttpGet("access-logs/me")]
        public async Task<IActionResult> GetMyAccessLogs([FromQuery] int page = 1, [FromQuery] int pageSize = 20)
        {
            if (!TryGetCurrentUserId(out var userId))
                return Unauthorized(new { message = "Token kh�ng h?p l?" });

            try
            {
                return Ok(await _accessLog.SearchMineAsync(userId, page, pageSize));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "L?i khi �?c nh?t k? truy c?p eKYC c?a user {UserId}", userId);
                return StatusCode(500, new { message = "C� l?i x?y ra, vui l?ng th? l?i" });
            }
        }

        private static string? ValidateImage(IFormFile? file, string name)
        {
            if (file is null || file.Length == 0)
                return $"Thi?u ?nh {name}";
            if (file.Length > MaxImageBytes)
                return $"?nh {name} qu� l?n (t?i �a {MaxImageBytes / 1024 / 1024} MB)";
            if (!AllowedContentTypes.Contains(file.ContentType, StringComparer.OrdinalIgnoreCase))
                return $"?nh {name} ph?i l� JPG ho?c PNG";
            return null;
        }

        private bool TryGetCurrentUserId(out int userId)
        {
            userId = 0;
            var claim = User.FindFirst("userId") ?? User.FindFirst(ClaimTypes.NameIdentifier);
            return claim is not null && int.TryParse(claim.Value, out userId);
        }
    }
}