using System.Text.Json;
using BookingAPI.DTOS;
using StackExchange.Redis;
using TicketAPI.API;
using TicketAPI.DTOs;
using TicketAPI.Models;

namespace TicketAPI.Services
{
    public class HoldService : IHoldService
    {
        private static readonly JsonSerializerOptions JsonOptions =
            new(JsonSerializerDefaults.Web)
            {
                PropertyNameCaseInsensitive = true
            };

        private readonly IDatabase _db;
        private readonly EventEligibilityClient _eligibility;
        private readonly IEventApiClient _eventApiClient;
        private readonly ILogger<HoldService> _logger;

        public HoldService(
            IConnectionMultiplexer redis,
            ILogger<HoldService> logger,
            IEventApiClient eventApiClient, EventEligibilityClient eligibility)
        {
            _db = redis.GetDatabase();
            _logger = logger;
            _eventApiClient = eventApiClient;
            _eligibility = eligibility;
        }

        public async Task<bool> TryHoldSeatAsync(
            int eventId,
            int seatId,
            int userId,
            int durationSeconds = 600)
        {
            ValidatePositive(eventId, nameof(eventId));
            ValidatePositive(seatId, nameof(seatId));
            ValidatePositive(userId, nameof(userId));
            ValidateDuration(durationSeconds);

            await _eligibility.EnsureSalesAsync(eventId);
            return await _db.StringSetAsync(
                SeatKey(eventId, seatId),
                userId,
                TimeSpan.FromSeconds(durationSeconds),
                When.NotExists);
        }

        public async Task<bool> TryHoldTicketsWithCapacityAsync(
            int ticketTypeId,
            int userId,
            int quantity,
            int availableCapacity,
            int durationSeconds)
        {
            ValidatePositive(ticketTypeId, nameof(ticketTypeId));
            ValidatePositive(userId, nameof(userId));
            ValidatePositive(quantity, nameof(quantity));
            ValidateDuration(durationSeconds);

            if (availableCapacity < quantity)
                return false;

            var userKey = TicketUserKey(ticketTypeId, userId);
            var totalKey = TicketTotalKey(ticketTypeId);
            var activeKey = TicketActiveKey(ticketTypeId);
            var quantitiesKey = TicketQuantitiesKey(ticketTypeId);

            const string script = """
                local now = tonumber(ARGV[1])
                local userId = ARGV[2]
                local quantity = tonumber(ARGV[3])
                local capacity = tonumber(ARGV[4])
                local duration = tonumber(ARGV[5])
                local userKeyPrefix = ARGV[6]

                local expiredUsers =
                    redis.call('ZRANGEBYSCORE', KEYS[3], '-inf', now)

                for _, expiredUserId in ipairs(expiredUsers) do
                    redis.call('DEL', userKeyPrefix .. expiredUserId)
                    redis.call('HDEL', KEYS[4], expiredUserId)
                    redis.call('ZREM', KEYS[3], expiredUserId)
                end

                if redis.call('ZSCORE', KEYS[3], userId) then
                    return 0
                end

                if redis.call('EXISTS', userKeyPrefix .. userId) == 1 then
                    return 0
                end

                local quantities = redis.call('HVALS', KEYS[4])
                local total = 0

                for _, heldQuantity in ipairs(quantities) do
                    total = total + tonumber(heldQuantity)
                end

                if total + quantity > capacity then
                    redis.call('SET', KEYS[2], total)
                    return 0
                end

                local expiresAt = now + duration

                redis.call(
                    'SET',
                    userKeyPrefix .. userId,
                    quantity,
                    'EX',
                    duration
                )

                redis.call('HSET', KEYS[4], userId, quantity)
                redis.call('ZADD', KEYS[3], expiresAt, userId)
                redis.call('SET', KEYS[2], total + quantity, 'EX', duration + 60)

                redis.call('EXPIRE', KEYS[3], duration + 60)
                redis.call('EXPIRE', KEYS[4], duration + 60)

                return 1
                """;

            var result = (long)await _db.ScriptEvaluateAsync(
                script,
                new RedisKey[]
                {
                    userKey,
                    totalKey,
                    activeKey,
                    quantitiesKey
                },
                new RedisValue[]
                {
                    DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
                    userId,
                    quantity,
                    availableCapacity,
                    durationSeconds,
                    $"hold:ticket:{ticketTypeId}:user:"
                });

            return result == 1;
        }

        public async Task<bool> ReleaseTicketsAsync(
            int ticketTypeId,
            int userId,
            int quantity)
        {
            var userKey = TicketUserKey(ticketTypeId, userId);
            var totalKey = TicketTotalKey(ticketTypeId);
            var activeKey = TicketActiveKey(ticketTypeId);
            var quantitiesKey = TicketQuantitiesKey(ticketTypeId);

            const string script = """
                local held = redis.call('GET', KEYS[1])

                if not held then
                    redis.call('HDEL', KEYS[4], ARGV[1])
                    redis.call('ZREM', KEYS[3], ARGV[1])
                    return 0
                end

                redis.call('DEL', KEYS[1])
                redis.call('HDEL', KEYS[4], ARGV[1])
                redis.call('ZREM', KEYS[3], ARGV[1])

                local quantities = redis.call('HVALS', KEYS[4])
                local total = 0

                for _, heldQuantity in ipairs(quantities) do
                    total = total + tonumber(heldQuantity)
                end

                if total <= 0 then
                    redis.call('DEL', KEYS[2])
                    return 1
                end

                local ttl = redis.call('TTL', KEYS[3])

                if ttl > 0 then
                    redis.call('SET', KEYS[2], total, 'EX', ttl)
                else
                    redis.call('SET', KEYS[2], total, 'EX', 60)
                end

                return 1
                """;

            var result = (long)await _db.ScriptEvaluateAsync(
                script,
                new RedisKey[]
                {
                    userKey,
                    totalKey,
                    activeKey,
                    quantitiesKey
                },
                new RedisValue[] { userId });

            return result == 1;
        }

        public async Task<SeatHoldInfo?> GetHoldInfoAsync(int eventId, int seatId)
        {
            var value = await _db.StringGetAsync(SeatKey(eventId, seatId));

            if (value.IsNull)
                return null;

            return new SeatHoldInfo
            {
                UserId = (int)value
            };
        }

        public async Task<TicketHoldInfo?> GetTicketHoldInfoAsync(
            int ticketTypeId,
            int userId)
        {
            var value = await _db.StringGetAsync(
                TicketUserKey(ticketTypeId, userId));

            if (value.IsNull)
                return null;

            return new TicketHoldInfo
            {
                Quantity = (int)value
            };
        }

        public async Task<HoldSessionResponse> CreateHoldSessionAsync(
            int userId,
            CreateHoldSessionRequest request,
            int? durationSeconds = null)
        {
            ValidatePositive(userId, nameof(userId));

            if (request == null)
                throw new ArgumentNullException(nameof(request));

            ValidatePositive(request.EventId, nameof(request.EventId));

            var tickets = request.Tickets ?? new List<TicketHoldItem>();
            var seatIds = request.SeatIds ?? new List<int>();

            if (tickets.Count == 0 && seatIds.Count == 0)
                throw new ArgumentException("Bạn chưa chọn vé hoặc ghế.");

            if (tickets.Any(ticket =>
                    ticket.TicketTypeId <= 0 || ticket.Quantity <= 0))
            {
                throw new ArgumentException(
                    "TicketTypeId và Quantity phải lớn hơn 0.");
            }

            if (tickets.GroupBy(ticket => ticket.TicketTypeId)
                       .Any(group => group.Count() > 1))
            {
                throw new ArgumentException(
                    "Một loại vé chỉ được xuất hiện một lần trong request.");
            }

            if (seatIds.Any(seatId => seatId <= 0) ||
                seatIds.Distinct().Count() != seatIds.Count)
            {
                throw new ArgumentException(
                    "Danh sách SeatIds không hợp lệ hoặc có ghế bị lặp.");
            }

            await _eligibility.EnsureSalesAsync(request.EventId);
            var eventInfo =
                await _eventApiClient.GetEventByIdAsync(request.EventId);

            if (eventInfo?.TicketTypes == null)
            {
                throw new InvalidOperationException(
                    $"Không lấy được thông tin vé của sự kiện {request.EventId}.");
            }

            int effectiveDurationSeconds = durationSeconds.HasValue && durationSeconds.Value > 0
                ? durationSeconds.Value
                : (eventInfo.HoldTimeoutMinutes > 0 ? eventInfo.HoldTimeoutMinutes * 60 : 600);
            ValidateDuration(effectiveDurationSeconds);

            var ticketCapacities = new Dictionary<int, int>();

            foreach (var ticket in tickets)
            {
                var ticketInfo = eventInfo.TicketTypes.FirstOrDefault(
                    item => item.TicketTypeId == ticket.TicketTypeId);

                if (ticketInfo == null)
                {
                    throw new ArgumentException(
                        $"Loại vé {ticket.TicketTypeId} không thuộc sự kiện này.");
                }

                if (ticketInfo.Status != "Active" || ticketInfo.SalesStartsAt > DateTime.UtcNow || ticketInfo.SalesEndsAt <= DateTime.UtcNow)
                    throw new InvalidOperationException("This ticket type is not currently on sale.");
                ticketCapacities[ticket.TicketTypeId] =
                    Math.Max(0, ticketInfo.Quantity - ticketInfo.SoldQuantity);
            }

            var holdId = Guid.NewGuid().ToString("N");
            var userLockKey = $"hold:user:{userId}:active";

            var acquired = await _db.StringSetAsync(
                userLockKey,
                holdId,
                TimeSpan.FromSeconds(effectiveDurationSeconds),
                When.NotExists);

            if (!acquired)
            {
                throw new InvalidOperationException(
                    "Bạn đang có phiên giữ vé. Vui lòng tiếp tục thanh toán hoặc chờ phiên hết hạn.");
            }

            var heldTickets = new List<TicketHoldItem>();
            var heldSeats = new List<int>();
            string? sessionKey = null;

            try
            {
                foreach (var ticket in tickets)
                {
                    var held = await TryHoldTicketsWithCapacityAsync(
                        ticket.TicketTypeId,
                        userId,
                        ticket.Quantity,
                        ticketCapacities[ticket.TicketTypeId],
                        effectiveDurationSeconds);

                    if (!held)
                    {
                        throw new InvalidOperationException(
                            $"Không giữ được vé loại {ticket.TicketTypeId}. " +
                            "Vé có thể đã hết hoặc bạn đang giữ loại vé này.");
                    }

                    heldTickets.Add(ticket);
                }

                foreach (var seatId in seatIds)
                {
                    var held = await TryHoldSeatAsync(
                        request.EventId,
                        seatId,
                        userId,
                        effectiveDurationSeconds);

                    if (!held)
                    {
                        throw new InvalidOperationException(
                            $"Ghế {seatId} vừa được người khác chọn.");
                    }

                    heldSeats.Add(seatId);
                }

                var session = new HoldSession
                {
                    HoldId = holdId,
                    UserId = userId,
                    EventId = request.EventId,
                    CreatedAtUtc = DateTime.UtcNow,
                    DurationSeconds = effectiveDurationSeconds,
                    ExpiresAtUtc = DateTime.UtcNow.AddSeconds(effectiveDurationSeconds),
                    Tickets = tickets,
                    SeatIds = seatIds
                };

                sessionKey = SessionKey(session.HoldId);

                var saved = await _db.StringSetAsync(
                    sessionKey,
                    JsonSerializer.Serialize(session, JsonOptions),
                    TimeSpan.FromSeconds(effectiveDurationSeconds),
                    When.NotExists);

                if (!saved)
                    throw new InvalidOperationException(
                        "Không lưu được hold session.");

                _logger.LogInformation(
                    "Tạo hold session {HoldId} cho user {UserId}, event {EventId}",
                    session.HoldId,
                    userId,
                    request.EventId);

                return ToResponse(session);
            }
            catch
            {
                if (sessionKey != null)
                    await _db.KeyDeleteAsync(sessionKey);

                foreach (var ticket in heldTickets)
                {
                    await ReleaseTicketsAsync(
                        ticket.TicketTypeId,
                        userId,
                        ticket.Quantity);
                }

                foreach (var seatId in heldSeats)
                {
                    await ReleaseSeatAsync(
                        request.EventId,
                        seatId,
                        userId);
                }

                await ReleaseUserHoldLockAsync(userId, holdId);

                throw;
            }
        }

        private async Task ReleaseUserHoldLockAsync(int userId, string holdId)
        {
            const string script = """
            if redis.call('GET', KEYS[1]) == ARGV[1] then
                return redis.call('DEL', KEYS[1])
            end
            return 0
            """;

            await _db.ScriptEvaluateAsync(
                script,
                new RedisKey[] { $"hold:user:{userId}:active" },
                new RedisValue[] { holdId });
        }

        public async Task<HoldSessionResponse> GetHoldDetailsAsync(
            string holdId,
            int userId)
        {
            if (string.IsNullOrWhiteSpace(holdId))
                throw new ArgumentException("HoldId không hợp lệ.");

            ValidatePositive(userId, nameof(userId));

            var key = SessionKey(holdId);
            var json = await _db.StringGetAsync(key);

            if (json.IsNull)
            {
                throw new KeyNotFoundException(
                    "Phiên giữ vé không tồn tại hoặc đã hết hạn.");
            }

            var session = JsonSerializer.Deserialize<HoldSession>(
                json.ToString(),
                JsonOptions);

            if (session == null)
                throw new InvalidOperationException(
                    "Dữ liệu hold session không hợp lệ.");

            if (session.UserId != userId)
                throw new UnauthorizedAccessException(
                    "Bạn không có quyền xem phiên giữ vé này.");

            var remainingSeconds = (int)Math.Ceiling(
                (session.ExpiresAtUtc - DateTime.UtcNow).TotalSeconds);

            if (remainingSeconds <= 0)
            {
                await _db.KeyDeleteAsync(key);

                throw new KeyNotFoundException(
                    "Phiên giữ vé đã hết hạn.");
            }

            await _eligibility.EnsureSalesAsync(session.EventId);
            var response = ToResponse(session, remainingSeconds);
            await EnrichTicketsAsync(response);
            return response;
        }

        // Gắn tên vé + đơn giá (nguồn: EventAPI) vào phản hồi để frontend hiển thị "vé đang mua".
        private async Task EnrichTicketsAsync(HoldSessionResponse response)
        {
            try
            {
                var eventInfo = await _eventApiClient.GetEventByIdAsync(response.EventId);
                if (eventInfo?.TicketTypes == null) return;

                response.Tickets = response.Tickets.Select(ticket =>
                {
                    var type = eventInfo.TicketTypes.FirstOrDefault(
                        t => t.TicketTypeId == ticket.TicketTypeId);

                    return new TicketHoldItem
                    {
                        TicketTypeId = ticket.TicketTypeId,
                        Quantity = ticket.Quantity,
                        TypeName = type?.TypeName,
                        UnitPrice = type?.Price
                    };
                }).ToList();

                response.TotalAmount = response.Tickets.Sum(
                    t => (t.UnitPrice ?? 0L) * t.Quantity);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex,
                    "Không lấy được tên/giá vé cho hold {HoldId}", response.HoldId);
            }
        }

        public async Task<bool> ReleaseSeatAsync(
            int eventId,
            int seatId,
            int userId)
        {
            var key = SeatKey(eventId, seatId);

            const string script = """
                local owner = redis.call('GET', KEYS[1])

                if owner and owner == ARGV[1] then
                    return redis.call('DEL', KEYS[1])
                end

                return 0
                """;

            var result = (long)await _db.ScriptEvaluateAsync(
                script,
                new RedisKey[] { key },
                new RedisValue[] { userId });

            return result == 1;
        }

        private static HoldSessionResponse ToResponse(
            HoldSession session,
            int? remainingSeconds = null)
        {
            var seconds = remainingSeconds ??
                (int)Math.Ceiling(
                    (session.ExpiresAtUtc - DateTime.UtcNow).TotalSeconds);

            return new HoldSessionResponse
            {
                HoldId = session.HoldId,
                EventId = session.EventId,
                CreatedAtUtc = session.CreatedAtUtc,
                DurationSeconds = session.DurationSeconds,
                ExpiresAtUtc = session.ExpiresAtUtc,
                RemainingSeconds = Math.Max(0, seconds),
                Tickets = session.Tickets,
                SeatIds = session.SeatIds,
                Attendees = session.Attendees
            };
        }

        private static string SeatKey(int eventId, int seatId) =>
            $"hold:seat:{eventId}:{seatId}";

        private static string TicketUserKey(int ticketTypeId, int userId) =>
            $"hold:ticket:{ticketTypeId}:user:{userId}";

        private static string TicketTotalKey(int ticketTypeId) =>
            $"hold:ticket:{ticketTypeId}:total";

        private static string TicketActiveKey(int ticketTypeId) =>
            $"hold:ticket:{ticketTypeId}:active";

        private static string TicketQuantitiesKey(int ticketTypeId) =>
            $"hold:ticket:{ticketTypeId}:quantities";

        private static string SessionKey(string holdId) =>
            $"hold:session:{holdId}";

        private static void ValidatePositive(int value, string name)
        {
            if (value <= 0)
            {
                throw new ArgumentOutOfRangeException(
                    name,
                    "Giá trị phải lớn hơn 0.");
            }
        }

        private static void ValidateDuration(int durationSeconds)
        {
            if (durationSeconds <= 0)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(durationSeconds),
                    "Thời hạn giữ vé phải lớn hơn 0.");
            }
        }

        public async Task<List<int>> GetHeldSeatIdsAsync(
            int eventId,
            IReadOnlyCollection<int> seatIds)
        {
            var ids = seatIds
                .Where(id => id > 0)
                .Distinct()
                .ToArray();

            var checks = ids.Select(async seatId =>
            {
                var value = await _db.StringGetAsync(SeatKey(eventId, seatId));
                return (SeatId: seatId, IsHeld: !value.IsNull);
            });

            var results = await Task.WhenAll(checks);

            return results
                .Where(result => result.IsHeld)
                .Select(result => result.SeatId)
                .ToList();
        }

        public async Task<HoldSessionResponse> SaveAttendeesAsync(string holdId, int userId, List<HoldAttendeeDto> attendees)
        {
            if (string.IsNullOrWhiteSpace(holdId))
                throw new ArgumentException("HoldId không hợp lệ.");

            ValidatePositive(userId, nameof(userId));

            if (attendees == null || attendees.Count == 0)
                throw new ArgumentException("Danh sách attendee không được để trống.");

            var key = SessionKey(holdId);
            var json = await _db.StringGetAsync(key);

            if (json.IsNull)
                throw new KeyNotFoundException(
                    "Phiên giữ vé không tồn tại hoặc đã hết hạn.");

            var session = JsonSerializer.Deserialize<HoldSession>(
                json.ToString(),
                JsonOptions);

            if (session == null)
                throw new InvalidOperationException(
                    "Dữ liệu hold session không hợp lệ.");

            if (session.UserId != userId)
                throw new UnauthorizedAccessException(
                    "Bạn không có quyền cập nhật phiên giữ vé này.");

            var remainingSeconds = (int)Math.Ceiling(
                (session.ExpiresAtUtc - DateTime.UtcNow).TotalSeconds);

            var redisTtl = await _db.KeyTimeToLiveAsync(key);

            if (remainingSeconds <= 0 || redisTtl == null || redisTtl <= TimeSpan.Zero)
                throw new KeyNotFoundException("Phiên giữ vé đã hết hạn.");

            var expectedCount = session.SeatIds.Count > 0
                ? session.SeatIds.Count
                : session.Tickets.Sum(ticket => ticket.Quantity);

            if (attendees.Count != expectedCount)
            {
                throw new ArgumentException(
                    $"Cần nhập thông tin cho {expectedCount} attendee.");
            }

            session.Attendees = attendees;

            var ttlToKeep = redisTtl.Value < TimeSpan.FromSeconds(remainingSeconds)
                ? redisTtl.Value
                : TimeSpan.FromSeconds(remainingSeconds);

            var saved = await _db.StringSetAsync(
                key,
                JsonSerializer.Serialize(session, JsonOptions),
                ttlToKeep,
                When.Exists);

            if (!saved)
                throw new KeyNotFoundException("Phiên giữ vé đã hết hạn.");

            await _eligibility.EnsureSalesAsync(session.EventId);
            return ToResponse(session, remainingSeconds);
        }

        public async Task CancelHoldSessionAsync(string holdId, int userId)
        {
            if (string.IsNullOrWhiteSpace(holdId))
                throw new ArgumentException("HoldId không hợp lệ.");

            ValidatePositive(userId, nameof(userId));

            var sessionKey = SessionKey(holdId);
            var json = await _db.StringGetAsync(sessionKey);

            if (json.IsNull)
            {
                throw new KeyNotFoundException(
                    "Phiên giữ vé không tồn tại hoặc đã hết hạn.");
            }

            var session = JsonSerializer.Deserialize<HoldSession>(
                json.ToString(),
                JsonOptions);

            if (session == null)
            {
                throw new InvalidOperationException(
                    "Dữ liệu hold session không hợp lệ.");
            }

            if (session.UserId != userId)
            {
                throw new UnauthorizedAccessException(
                    "Bạn không có quyền hủy phiên giữ vé này.");
            }

            foreach (var ticket in session.Tickets ?? new List<TicketHoldItem>())
            {
                await ReleaseTicketsAsync(
                    ticket.TicketTypeId,
                    userId,
                    ticket.Quantity);
            }

            foreach (var seatId in session.SeatIds ?? new List<int>())
            {
                await ReleaseSeatAsync(
                    session.EventId,
                    seatId,
                    userId);
            }

            await _db.KeyDeleteAsync(sessionKey);
            await ReleaseUserHoldLockAsync(userId, session.HoldId);

            _logger.LogInformation(
                "Đã hủy hold session {HoldId} của user {UserId}",
                holdId,
                userId);
        }

        public async Task<HoldSessionResponse?> GetActiveHoldSessionAsync(int userId)
        {
            ValidatePositive(userId, nameof(userId));

            var lockKey = $"hold:user:{userId}:active";
            var holdIdValue = await _db.StringGetAsync(lockKey);

            if (holdIdValue.IsNull)
                return null;

            var holdId = holdIdValue.ToString();

            try
            {
                return await GetHoldDetailsAsync(holdId, userId);
            }
            catch (KeyNotFoundException)
            {
                await ReleaseUserHoldLockAsync(userId, holdId);
                return null;
            }
        }

        public async Task<HoldSessionResponse> ChangeSeatsAsync(
            string holdId,
            int userId,
            List<int> seatIds)
        {
            if (string.IsNullOrWhiteSpace(holdId))
                throw new ArgumentException("HoldId không hợp lệ.");

            ValidatePositive(userId, nameof(userId));

            if (seatIds == null || seatIds.Count == 0)
                throw new ArgumentException("Bạn phải chọn ít nhất một ghế.");

            if (seatIds.Any(id => id <= 0) ||
                seatIds.Distinct().Count() != seatIds.Count)
            {
                throw new ArgumentException("Danh sách ghế không hợp lệ hoặc có ghế bị lặp.");
            }

            var sessionKey = SessionKey(holdId);
            var sessionJson = await _db.StringGetAsync(sessionKey);

            if (sessionJson.IsNull)
                throw new KeyNotFoundException("Phiên giữ vé không tồn tại hoặc đã hết hạn.");

            var session = JsonSerializer.Deserialize<HoldSession>(
                sessionJson.ToString(),
                JsonOptions);

            if (session == null)
                throw new InvalidOperationException("Dữ liệu hold session không hợp lệ.");

            if (session.UserId != userId)
                throw new UnauthorizedAccessException(
                    "Bạn không có quyền cập nhật phiên giữ vé này.");

            var remainingSeconds = (int)Math.Ceiling(
                (session.ExpiresAtUtc - DateTime.UtcNow).TotalSeconds);

            var sessionTtl = await _db.KeyTimeToLiveAsync(sessionKey);

            if (remainingSeconds <= 0 ||
                sessionTtl == null ||
                sessionTtl <= TimeSpan.Zero)
            {
                throw new KeyNotFoundException("Phiên giữ vé đã hết hạn.");
            }

            var currentSeatIds = session.SeatIds ?? new List<int>();

            if (currentSeatIds.Count == 0)
                throw new InvalidOperationException(
                    "Phiên giữ vé này không có ghế để thay đổi.");

            if (seatIds.Count != currentSeatIds.Count)
                throw new ArgumentException(
                    $"Bạn cần chọn đúng {currentSeatIds.Count} ghế.");

            await _eligibility.EnsureSalesAsync(session.EventId);

            var ttl = sessionTtl.Value < TimeSpan.FromSeconds(remainingSeconds)
                ? sessionTtl.Value
                : TimeSpan.FromSeconds(remainingSeconds);

            var currentSeatSet = currentSeatIds.ToHashSet();
            var newlyAcquiredSeatIds = new List<int>();

            foreach (var seatId in seatIds)
            {
                if (currentSeatSet.Contains(seatId))
                    continue;

                var acquired = await _db.StringSetAsync(
                    SeatKey(session.EventId, seatId),
                    userId,
                    ttl,
                    When.NotExists);

                if (!acquired)
                {
                    foreach (var acquiredSeatId in newlyAcquiredSeatIds)
                    {
                        await ReleaseSeatAsync(
                            session.EventId,
                            acquiredSeatId,
                            userId);
                    }

                    throw new InvalidOperationException(
                        $"Ghế {seatId} vừa được người khác chọn. Các ghế bạn đang giữ vẫn được giữ nguyên.");
                }

                newlyAcquiredSeatIds.Add(seatId);
            }

            var previousSeatIds = currentSeatIds.ToList();

            session.SeatIds = seatIds.ToList();

            if (session.Attendees != null &&
                session.Attendees.Count == seatIds.Count)
            {
                for (var i = 0; i < session.Attendees.Count; i++)
                {
                    session.Attendees[i].SeatId = seatIds[i];
                }
            }

            var saved = await _db.StringSetAsync(
                sessionKey,
                JsonSerializer.Serialize(session, JsonOptions),
                ttl,
                When.Exists);

            if (!saved)
            {
                foreach (var acquiredSeatId in newlyAcquiredSeatIds)
                {
                    await ReleaseSeatAsync(
                        session.EventId,
                        acquiredSeatId,
                        userId);
                }

                throw new KeyNotFoundException(
                    "Phiên giữ vé đã hết hạn trong lúc cập nhật ghế.");
            }

            foreach (var oldSeatId in previousSeatIds)
            {
                if (!seatIds.Contains(oldSeatId))
                {
                    await ReleaseSeatAsync(
                        session.EventId,
                        oldSeatId,
                        userId);
                }
            }

            var response = ToResponse(session, remainingSeconds);
            await EnrichTicketsAsync(response);

            return response;
        }
    }
}